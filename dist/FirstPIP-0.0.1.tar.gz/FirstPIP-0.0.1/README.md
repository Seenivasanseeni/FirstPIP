#FirstPIP package
This is a simple greeter package for learning packaging python objects